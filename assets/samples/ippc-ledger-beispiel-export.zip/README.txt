IPPC Ledger evidence export: DELIVERIES-2026-08-07-2026-10-06
Generated: 2026-10-06T06:02:53.211619+00:00 (UTC)

documents/      original evidence files, byte-identical to the uploads (verified against their SHA-256)
manifest.csv    one row per file and relationship: job, delivery, supplier, material, hash
jobs.csv, material.csv, deliveries.csv, suppliers.csv   the records
completeness.csv   missing or unestablished information found by the deterministic rules
audit.csv       history of the included records, with the reason given for every correction
summary.pdf     a printable overview of this export

Document review and verification columns are statements by the named user, not certifications.
This export supports record-keeping. It is not an official certificate or a statement of compliance.
