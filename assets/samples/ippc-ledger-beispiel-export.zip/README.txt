﻿IPPC Ledger Nachweis-Export: DELIVERIES-2026-08-23-2026-10-22
Erstellt: 2026-10-22 09:22 UTC

documents/      Original-Nachweisdateien, bytegleich mit den hochgeladenen Dateien (gegen ihre SHA-256 geprüft)
manifest.csv    eine Zeile je Datei und Bezug: Auftrag, Wareneingang, Lieferant, Material, Prüfsumme
jobs.csv, material.csv, deliveries.csv, suppliers.csv die erfassten Daten
completeness.csv fehlende oder nicht belegte Angaben, gefunden von den festen Prüfregeln
requests.csv    Nachweisanforderungen an Lieferanten: offen, erfüllt, storniert; eingegangene Dateien einschließlich abgelehnter (abgelehnte oder ungeprüfte Dateien werden aufgeführt, aber nie als Nachweis verpackt)
audit.csv       Verlauf der enthaltenen Daten, mit dem Grund jeder Korrektur
summary.pdf     eine druckbare Übersicht über diesen Export

Spaltennamen und Codes der CSV-Dateien (Status, Regel, Aktion) sind in jeder Sprache gleich; siehe die Beschreibung des Exportformats.
Die Spalten zu Prüfung und Abgleich von Dokumenten sind Angaben der genannten Person, keine Bescheinigungen.
Dieser Export unterstützt die Dokumentation. Er ist keine amtliche Bescheinigung und keine Konformitätserklärung.
