﻿IPPC Ledger evidence export: DELIVERIES-2026-08-23-2026-10-22
Generated: 2026-10-22 09:22 UTC

documents/      original evidence files, byte-identical to the uploads (verified against their SHA-256)
manifest.csv    one row per file and relationship: job, delivery, supplier, material, hash
jobs.csv, material.csv, deliveries.csv, suppliers.csv the records
completeness.csv missing or unestablished information found by the deterministic rules
requests.csv    document requests to suppliers: open, fulfilled, cancelled; received files incl. rejected ones (rejected or unreviewed files are listed, never packed as evidence)
audit.csv       history of the included records, with the reason given for every correction
summary.pdf     a printable overview of this export

CSV column names and codes (status, rule, action) are the same in every language; see the export format documentation.
Document review and verification columns are statements by the named user, not certifications.
This export supports record-keeping. It is not an official certificate or a statement of compliance.
